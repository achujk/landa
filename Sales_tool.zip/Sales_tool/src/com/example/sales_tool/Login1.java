package com.example.sales_tool;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;
 
import cz.msebera.android.httpclient.*;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login1 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login1);
		
		Button btn=(Button) findViewById(R.id.b1);
		btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				//Intent i=new Intent(getApplicationContext(),Product.class);
				//startActivity(i);
				
				EditText txtusername= (EditText) findViewById(R.id.username);
				EditText txtpassword= (EditText) findViewById(R.id.password);
				
			final	String username=txtusername.getText().toString();
				String password=txtpassword.getText().toString();
				
				
				
				  String url = IpActivity.IPADDRESS+"forms/login.php";
		            AsyncHttpClient client = new AsyncHttpClient();
		            RequestParams params = new RequestParams();
		            params.put("uname", username);
		            params.put("password", password);
		            client.get(url, params, new JsonHttpResponseHandler(){
		            	 @Override
			                public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
			                    // Root JSON in response is an dictionary i.e { "data : [ ... ] }
			                    // Handle resulting parsed JSON response here
			                    try {

			                        if(response.length()>0)
			                        {
			                            JSONObject jobject=  response.getJSONObject(0);
			                            String utype=jobject.getString("USERTYPE");
			                            if(utype.equals("customer"))
			                            {
			                                IpActivity.Username=username;
			                                Toast.makeText(getApplicationContext(),"welcome" , Toast.LENGTH_SHORT).show();
					                           
			                                Intent i = new Intent(getApplicationContext(),Product.class);
			                                startActivity(i);
			                            } 
			                            else
			                            {

			                                Toast.makeText(getApplicationContext(),"Login failed" , Toast.LENGTH_SHORT).show();
			                            }
			                        }else
			                        {
			                            Toast.makeText(getApplicationContext(),"Login failed no member found" , Toast.LENGTH_SHORT).show();
			                        }
			                       

			                    }
			                    catch(JSONException ex)
			                    {
			                        Toast.makeText(getApplicationContext(), "bbbbbb"+ex.getMessage(), Toast.LENGTH_SHORT).show();

			                    }


			                }

			                @Override
			                public void onFailure(int statusCode, Header[] headers, String res, Throwable t) {
			                    // called when response HTTP status is "4XX" (eg. 401, 403, 404)
			                    Toast.makeText(getApplicationContext(), res+"mmmmmmmmm", Toast.LENGTH_SHORT).show();

			                }
		            	
		            });
		           
			}      
		});
		Button btn1=(Button) findViewById(R.id.b2);
		btn1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i1=new Intent(getApplicationContext(),Customer_registration.class);
				startActivity(i1);
				
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login1, menu);
		return true;
	}

}
