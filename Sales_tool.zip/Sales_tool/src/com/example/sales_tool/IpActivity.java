package com.example.sales_tool;

/**
 * Created by u on 26/10/17.
 */

public class IpActivity {


    public static String IPADDRESS="http://192.168.43.190/salestool/Android/";
    public static int apppid=0;
    public static String Username;

}  
