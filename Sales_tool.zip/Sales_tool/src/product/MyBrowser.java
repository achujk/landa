package product;

import android.webkit.WebViewClient;

public class MyBrowser extends WebViewClient {

}
